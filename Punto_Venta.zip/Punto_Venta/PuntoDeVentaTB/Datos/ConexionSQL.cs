﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Entidades;

namespace Datos
{
    public class ConexionSQL
    {
        static string conexionstring = "server= LAPTOP-873A54EK\\SQLEXPRESS; database= PuntoDeVentaTB;" +
           "integrated security= true";
        SqlConnection con = new SqlConnection(conexionstring);

        public int consultalogin(string Usuario, string Contrasena)
        {
            int count;
            con.Open();

            string Query = "Select Count (*) From DB_Usuario where Usuario = '" + Usuario + "' " +
                " and contrasena = '" + Contrasena + "'";

            SqlCommand cmd = new SqlCommand(Query, con);
            count = Convert.ToInt32(cmd.ExecuteScalar());

            con.Close();
            return count;
        }

        public int InsertarUsuario(string nom, string apel, string dni, string tel, string user, string pass) 
        { 
            int flag = 0;
            con.Open();
            string query = "insert into DB_Usuario ([Nombre] ,[apellidos] ,[DNI] ,[Telefono] ,[Usuario] ,[Contrasena])" +
                "values ('" + nom+ "','" + apel + "','" + dni + "','" + tel + "', '" + user + "','" + pass + "')";
            SqlCommand cmd = new SqlCommand(query,con);
            flag = cmd.ExecuteNonQuery();
            con.Close();
            return flag;
        } 

        public int ModificarUsuario(string nom, string apel, string dni, string tel, string user, string pass) 
        {
            int flag = 0;
            con.Open();
            string query = "Update DB_Usuario set Nombre = '" + nom + "', apellidos = '" + apel + "', " +
                "Telefono = '" + tel + "',Usuario ='" + user + "', Contrasena ='" + pass + "' where  DNI = '" + dni + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            flag = cmd.ExecuteNonQuery();
            con.Close();
            return flag;

        }

        public int EliminarUsuario(string dni) 
        {
            int flag = 0;
            con.Open();

            string query = "Delete from DB_Usuario where dni = '" + dni + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            flag = cmd.ExecuteNonQuery();
            con.Close();

            return flag;
        }

        public DataTable ConsultaUsuariosDG()
        {
            String query = "Select * From DB_Usuario";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter data = new SqlDataAdapter(cmd);
            DataTable tabla = new DataTable();
            data.Fill(tabla);

            return tabla;

        }

        public DataTable ConsultaProductos()
        {
            String query = "Select * From Inventario";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter data = new SqlDataAdapter(cmd);
            DataTable tabla = new DataTable();
            data.Fill(tabla);

            return tabla;
        }

        public int InsertarProducto(string Prod, string Catg, string Prec, string Cant, string Codg)
        {
            int flag = 0;
            con.Open();
            string query = "insert into Inventario ([Producto] ,[Categoria] ,[Precio] ,[Cantidad], [Codigo])" +
                "values ('" + Prod + "','" + Catg + "','" + Prec + "','" + Cant + "','"+ Codg +"')";
            SqlCommand cmd = new SqlCommand(query, con);
            flag = cmd.ExecuteNonQuery();
            con.Close();
            return flag;
        }

        public int ModificarProducto(string Prod, string Catg, string Prec, string Cant, string Codg)
        {
            int flag = 0;
            con.Open();
            string query = "Update Inventario set Producto = '" + Prod + "', Categoria = '" + Catg + "', " +
                "Precio = '" + Prec + "',Cantidad ='" + Cant + "' where  Codigo = '" + Codg +"'";
            SqlCommand cmd = new SqlCommand(query, con);
            flag = cmd.ExecuteNonQuery();
            con.Close();
            return flag;

        }

        public string ConsultaFactura()
        {
            con.Open();
            string resultado = "NULL";
            string query = "  select(select distinct top 1 NumFactura from Facturacion order by NumFactura desc)+ 1 as NumFactura";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reg = cmd.ExecuteReader();

            if (reg.Read()) 
            {
                resultado = reg["NumFactura"].ToString();

            }

            con.Close();
            return resultado;

        }

        public Tuple<string,string> ConsultaProdInv(string codigo)
        {
            con.Open();
            string resultado = "NULL";
            string resultado1 = "NULL";
            string query = "  select * From Inventario where Codigo = '"+codigo+"'";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reg = cmd.ExecuteReader();

            if (reg.Read())
            {
                resultado = reg["Producto"].ToString();
                resultado1 = reg["Precio"].ToString();

            }

            con.Close();
            return Tuple.Create(resultado, resultado1);
        }

        public Tuple<string,string,string,string,string,string> ConsultaCliente(string ID)
        {
            con.Open();
            string T1 = "NULL";
            string T2 = "NULL";
            string T3 = "NULL";
            string T4 = "NULL";
            string T5 = "NULL";
            string T6 = "NULL";
            string query = "  select * From Clientes where ID = '" +ID+ "'";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reg = cmd.ExecuteReader();

            if (reg.Read())
            {
                T1 = reg["RFC"].ToString();
                T2 = reg["NombreCl"].ToString();
                T3 = reg["CodigoP"].ToString();
                T4 = reg["Direccion"].ToString();
                T5 = reg["TelefonoCl"].ToString();
                T6 = reg["CorreoCl"].ToString();
            }

            con.Close();
            return Tuple.Create(T1, T2, T3,T4,T5,T6);
        }

        public void InsertarFactura(List<Factura> F)
        {
            con.Open();

            foreach (Factura fact in F)
            {

                string query = "insert into Facturacion ([Codigo],[Producto],[Precioxunidad],[cantidad],[Cliente],[Direccion],[CodigoPost],[RFC],[CDFI],[TelfonoCl],[Correo],[MetodoPago],[MontoTotal],[NumFactura])" +
                    "values ('"+fact.Codigo+"','"+fact.Producto+"','"+fact.PrecioxUnidad+"','"+fact.Cantidad+"','"+fact.Cliente+"','"+fact.Direccion+"','"+fact.CodigoPost+"','"+fact.RFC+"','"+fact.CDFI+"','"+fact.TelfonoCl+"','"+fact.Correo+"','"+fact.MetodoPago+"','"+fact.PrecioTotal+"','"+fact.NumFactura+"')";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();

            }

            con.Close();

        }

        public DataTable ConsultaClientes()
        {
            String query = "Select * From Clientes";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter data = new SqlDataAdapter(cmd);
            DataTable tabla = new DataTable();
            data.Fill(tabla);

            return tabla;
        }

        public int InsertarCliente(string Rfc, string NomCl, string CodgP, string DircCl, string TelCl, string CorreoCl)
        {
            int flag = 0;
            con.Open();
            string query = "insert into Clientes ( [RFC],[NombreCl],[CodigoP],[Direccion],[TelefonoCl],[CorreoCl])" +
                "values ('" + Rfc + "','" + NomCl + "','" + CodgP + "','" + DircCl + "','" + TelCl + "','"+ CorreoCl +"')";
            SqlCommand cmd = new SqlCommand(query, con);
            flag = cmd.ExecuteNonQuery();
            con.Close();
            return flag;
        }

        public int ModificarCliente(string Rfc, string NomCl, string CodgP, string DircCl, string TelCl, string CorreoCl)
        {
            int flag = 0;
            con.Open();
            string query = "Update Clientes set RFC = '" + Rfc + "', CodigoP = '" + CodgP + "', " +
                "Direccion = '" + DircCl + "',TelefonoCl ='" + TelCl + "', CorreoCl = '"+ CorreoCl + "'  where  NombreCl = '" + NomCl + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            flag = cmd.ExecuteNonQuery();
            con.Close();
            return flag;

        }











    }


























    }

    







