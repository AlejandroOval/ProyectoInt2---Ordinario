﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Datos;
using Entidades;

namespace Negocios
{
    public class conexionSQLN
    {

        ConexionSQL cn = new ConexionSQL();

        public int conSql(string user, string pass)
        {
            return cn.consultalogin(user, pass);
        }


        public DataTable ConSultaDT()
        {
            return cn.ConsultaUsuariosDG();
        }

        public int InsertarUsuario(string nom, string apel, string dni, string tel, string user, string pass)
        {
            return cn.InsertarUsuario(nom,apel,dni,tel,user,pass);
        }

        public int ModificarUsuario(string nom, string apel, string dni, string tel, string user, string pass)
        {
            return cn.ModificarUsuario(nom, apel, dni, tel, user, pass);
        }

        public int EliminarUsuario(string dni)
        {
            return cn.EliminarUsuario(dni);
        }

        public DataTable ConsultaProductosDT()
        {
            return cn.ConsultaProductos();
        }

        public int InsertarProducto(string Prod, string Catg, string Prec, string Cant, string Codg)
        {
            return cn.InsertarProducto(Prod,Catg,Prec,Cant,Codg) ;
        }

        public int ModificarProducto(string Prod, string Catg, string Prec, string Cant, string Codg)
        {
            return cn.ModificarProducto(Prod,Catg,Prec,Cant, Codg);
        }

        public string ConsultaFactura()
        {
            return cn.ConsultaFactura();
        }

        public Tuple<string, string> ConsultaProdInv(string code)
        {
            return cn.ConsultaProdInv(code);
        }

        public Tuple<string, string, string, string, string, string> ConsultaCliente(string ID)
        {
            return cn.ConsultaCliente(ID);
        }

        public void InsertarFactura(List<Factura> F)
        {
            cn.InsertarFactura(F);
        }

        public DataTable ConSultaClientes()
        {
            return cn.ConsultaClientes();
        }

        public int InsertarCliente(string Rfc, string NomCl, string CodgP, string DircCl, string TelCl, string CorreoCl)
        {
 

            return cn.InsertarCliente(Rfc,NomCl,CodgP,DircCl,TelCl,CorreoCl);
        }

        public int ModificarCliente(string Rfc, string NomCl, string CodgP, string DircCl, string TelCl, string CorreoCl)
        {

            return cn.ModificarCliente(Rfc, NomCl, CodgP, DircCl, TelCl, CorreoCl);

        }








    }
}
