﻿namespace PuntoDeVentaTB
{
    partial class VentaPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VentaPrincipal));
            this.btn_Cerrar = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.Menu_Archivo = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_ImpVenta = new System.Windows.Forms.ToolStripMenuItem();
            this.txt_ImpVIni = new System.Windows.Forms.ToolStripTextBox();
            this.Menu_Usuarios = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_Inventario = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_Reportes = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_HistFactura = new System.Windows.Forms.ToolStripMenuItem();
            this.Menu_Clientes = new System.Windows.Forms.ToolStripMenuItem();
            this.txt_AgregarProd = new System.Windows.Forms.Button();
            this.txt_CodgProd = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lbl_SubTotal = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_Total = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_CodigoCliente = new System.Windows.Forms.TextBox();
            this.btn_BuscarCliente = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_NFactura = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_Cliente = new System.Windows.Forms.TextBox();
            this.btn_Facturar = new System.Windows.Forms.Button();
            this.txt_Cantidad = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_Impuestos = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_MetodoPago = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_UsoCFDI = new System.Windows.Forms.TextBox();
            this.txt_Direccion = new System.Windows.Forms.TextBox();
            this.txt_CodigPost = new System.Windows.Forms.TextBox();
            this.txt_RFC = new System.Windows.Forms.TextBox();
            this.txt_Telefono = new System.Windows.Forms.TextBox();
            this.txt_Correo = new System.Windows.Forms.TextBox();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Cerrar
            // 
            this.btn_Cerrar.Location = new System.Drawing.Point(817, 413);
            this.btn_Cerrar.Name = "btn_Cerrar";
            this.btn_Cerrar.Size = new System.Drawing.Size(90, 35);
            this.btn_Cerrar.TabIndex = 0;
            this.btn_Cerrar.Text = "Cerrar";
            this.btn_Cerrar.UseVisualStyleBackColor = true;
            this.btn_Cerrar.Click += new System.EventHandler(this.btn_Cerrar_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Menu_Archivo,
            this.Menu_Usuarios,
            this.Menu_Inventario,
            this.Menu_Reportes,
            this.Menu_Clientes});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(916, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // Menu_Archivo
            // 
            this.Menu_Archivo.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Menu_ImpVenta});
            this.Menu_Archivo.Name = "Menu_Archivo";
            this.Menu_Archivo.Size = new System.Drawing.Size(60, 20);
            this.Menu_Archivo.Text = "Archivo";
            this.Menu_Archivo.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // Menu_ImpVenta
            // 
            this.Menu_ImpVenta.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.txt_ImpVIni});
            this.Menu_ImpVenta.Name = "Menu_ImpVenta";
            this.Menu_ImpVenta.Size = new System.Drawing.Size(180, 22);
            this.Menu_ImpVenta.Text = "Imp venta";
            // 
            // txt_ImpVIni
            // 
            this.txt_ImpVIni.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_ImpVIni.Name = "txt_ImpVIni";
            this.txt_ImpVIni.Size = new System.Drawing.Size(100, 23);
            this.txt_ImpVIni.Text = "0.16";
            // 
            // Menu_Usuarios
            // 
            this.Menu_Usuarios.Name = "Menu_Usuarios";
            this.Menu_Usuarios.Size = new System.Drawing.Size(64, 20);
            this.Menu_Usuarios.Text = "Usuarios";
            this.Menu_Usuarios.Click += new System.EventHandler(this.Menu_Usuarios_Click);
            // 
            // Menu_Inventario
            // 
            this.Menu_Inventario.Name = "Menu_Inventario";
            this.Menu_Inventario.Size = new System.Drawing.Size(72, 20);
            this.Menu_Inventario.Text = "Inventario";
            this.Menu_Inventario.Click += new System.EventHandler(this.Menu_Inventario_Click);
            // 
            // Menu_Reportes
            // 
            this.Menu_Reportes.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Menu_HistFactura});
            this.Menu_Reportes.Name = "Menu_Reportes";
            this.Menu_Reportes.Size = new System.Drawing.Size(65, 20);
            this.Menu_Reportes.Text = "Reportes";
            // 
            // Menu_HistFactura
            // 
            this.Menu_HistFactura.Name = "Menu_HistFactura";
            this.Menu_HistFactura.Size = new System.Drawing.Size(181, 22);
            this.Menu_HistFactura.Text = "Historial de Facturas";
            // 
            // Menu_Clientes
            // 
            this.Menu_Clientes.Name = "Menu_Clientes";
            this.Menu_Clientes.Size = new System.Drawing.Size(61, 20);
            this.Menu_Clientes.Text = "Clientes";
            this.Menu_Clientes.Click += new System.EventHandler(this.Menu_Clientes_Click);
            // 
            // txt_AgregarProd
            // 
            this.txt_AgregarProd.Location = new System.Drawing.Point(406, 339);
            this.txt_AgregarProd.Name = "txt_AgregarProd";
            this.txt_AgregarProd.Size = new System.Drawing.Size(320, 53);
            this.txt_AgregarProd.TabIndex = 2;
            this.txt_AgregarProd.Text = "Agregar Producto";
            this.txt_AgregarProd.UseVisualStyleBackColor = true;
            this.txt_AgregarProd.Click += new System.EventHandler(this.txt_AgregarProd_Click);
            // 
            // txt_CodgProd
            // 
            this.txt_CodgProd.Location = new System.Drawing.Point(406, 304);
            this.txt_CodgProd.Name = "txt_CodgProd";
            this.txt_CodgProd.Size = new System.Drawing.Size(157, 20);
            this.txt_CodgProd.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(403, 288);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Codigo de Producto:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 42);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(107, 87);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(135, 65);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(772, 193);
            this.dataGridView1.TabIndex = 6;
            // 
            // lbl_SubTotal
            // 
            this.lbl_SubTotal.AutoSize = true;
            this.lbl_SubTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SubTotal.Location = new System.Drawing.Point(6, 28);
            this.lbl_SubTotal.Name = "lbl_SubTotal";
            this.lbl_SubTotal.Size = new System.Drawing.Size(84, 39);
            this.lbl_SubTotal.TabIndex = 8;
            this.lbl_SubTotal.Text = "0.00";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(141, 400);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 39);
            this.label4.TabIndex = 9;
            this.label4.Text = "Total:";
            // 
            // lbl_Total
            // 
            this.lbl_Total.AutoSize = true;
            this.lbl_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Total.Location = new System.Drawing.Point(274, 400);
            this.lbl_Total.Name = "lbl_Total";
            this.lbl_Total.Size = new System.Drawing.Size(91, 42);
            this.lbl_Total.TabIndex = 10;
            this.lbl_Total.Text = "0.00";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Codigo de cliente";
            // 
            // txt_CodigoCliente
            // 
            this.txt_CodigoCliente.Location = new System.Drawing.Point(12, 161);
            this.txt_CodigoCliente.Name = "txt_CodigoCliente";
            this.txt_CodigoCliente.Size = new System.Drawing.Size(100, 20);
            this.txt_CodigoCliente.TabIndex = 12;
            // 
            // btn_BuscarCliente
            // 
            this.btn_BuscarCliente.Location = new System.Drawing.Point(12, 188);
            this.btn_BuscarCliente.Name = "btn_BuscarCliente";
            this.btn_BuscarCliente.Size = new System.Drawing.Size(100, 26);
            this.btn_BuscarCliente.TabIndex = 13;
            this.btn_BuscarCliente.Text = "Buscar";
            this.btn_BuscarCliente.UseVisualStyleBackColor = true;
            this.btn_BuscarCliente.Click += new System.EventHandler(this.btn_BuscarCliente_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(135, 42);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Nº Factura:";
            // 
            // txt_NFactura
            // 
            this.txt_NFactura.Location = new System.Drawing.Point(202, 39);
            this.txt_NFactura.Name = "txt_NFactura";
            this.txt_NFactura.ReadOnly = true;
            this.txt_NFactura.Size = new System.Drawing.Size(100, 20);
            this.txt_NFactura.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(314, 39);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Cliente:";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // txt_Cliente
            // 
            this.txt_Cliente.Location = new System.Drawing.Point(362, 39);
            this.txt_Cliente.Name = "txt_Cliente";
            this.txt_Cliente.ReadOnly = true;
            this.txt_Cliente.Size = new System.Drawing.Size(309, 20);
            this.txt_Cliente.TabIndex = 17;
            // 
            // btn_Facturar
            // 
            this.btn_Facturar.Location = new System.Drawing.Point(746, 304);
            this.btn_Facturar.Name = "btn_Facturar";
            this.btn_Facturar.Size = new System.Drawing.Size(158, 88);
            this.btn_Facturar.TabIndex = 18;
            this.btn_Facturar.Text = "Facturar";
            this.btn_Facturar.UseVisualStyleBackColor = true;
            this.btn_Facturar.Click += new System.EventHandler(this.btn_Facturar_Click);
            // 
            // txt_Cantidad
            // 
            this.txt_Cantidad.Location = new System.Drawing.Point(569, 304);
            this.txt_Cantidad.Name = "txt_Cantidad";
            this.txt_Cantidad.Size = new System.Drawing.Size(157, 20);
            this.txt_Cantidad.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(569, 285);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 13);
            this.label9.TabIndex = 20;
            this.label9.Text = "Cantidad:";
            // 
            // txt_Impuestos
            // 
            this.txt_Impuestos.Location = new System.Drawing.Point(121, 32);
            this.txt_Impuestos.Name = "txt_Impuestos";
            this.txt_Impuestos.ReadOnly = true;
            this.txt_Impuestos.Size = new System.Drawing.Size(100, 20);
            this.txt_Impuestos.TabIndex = 21;
            this.txt_Impuestos.TextChanged += new System.EventHandler(this.txt_Impuestos_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(118, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 13);
            this.label10.TabIndex = 23;
            this.label10.Text = "Imp Venta:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txt_MetodoPago);
            this.groupBox1.Controls.Add(this.txt_Impuestos);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.lbl_SubTotal);
            this.groupBox1.Location = new System.Drawing.Point(135, 285);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(244, 107);
            this.groupBox1.TabIndex = 25;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sub Total:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(118, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 26;
            this.label2.Text = "Metodo de pago";
            // 
            // txt_MetodoPago
            // 
            this.txt_MetodoPago.Location = new System.Drawing.Point(121, 81);
            this.txt_MetodoPago.Name = "txt_MetodoPago";
            this.txt_MetodoPago.Size = new System.Drawing.Size(100, 20);
            this.txt_MetodoPago.TabIndex = 27;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(684, 42);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 13);
            this.label11.TabIndex = 26;
            this.label11.Text = "Uso CFDI:";
            // 
            // txt_UsoCFDI
            // 
            this.txt_UsoCFDI.Location = new System.Drawing.Point(746, 39);
            this.txt_UsoCFDI.Name = "txt_UsoCFDI";
            this.txt_UsoCFDI.Size = new System.Drawing.Size(158, 20);
            this.txt_UsoCFDI.TabIndex = 27;
            // 
            // txt_Direccion
            // 
            this.txt_Direccion.AccessibleRole = System.Windows.Forms.AccessibleRole.Alert;
            this.txt_Direccion.Location = new System.Drawing.Point(12, 238);
            this.txt_Direccion.Name = "txt_Direccion";
            this.txt_Direccion.Size = new System.Drawing.Size(100, 20);
            this.txt_Direccion.TabIndex = 28;
            // 
            // txt_CodigPost
            // 
            this.txt_CodigPost.Location = new System.Drawing.Point(12, 265);
            this.txt_CodigPost.Name = "txt_CodigPost";
            this.txt_CodigPost.Size = new System.Drawing.Size(100, 20);
            this.txt_CodigPost.TabIndex = 29;
            // 
            // txt_RFC
            // 
            this.txt_RFC.Location = new System.Drawing.Point(12, 293);
            this.txt_RFC.Name = "txt_RFC";
            this.txt_RFC.Size = new System.Drawing.Size(100, 20);
            this.txt_RFC.TabIndex = 30;
            // 
            // txt_Telefono
            // 
            this.txt_Telefono.Location = new System.Drawing.Point(12, 319);
            this.txt_Telefono.Name = "txt_Telefono";
            this.txt_Telefono.Size = new System.Drawing.Size(100, 20);
            this.txt_Telefono.TabIndex = 31;
            // 
            // txt_Correo
            // 
            this.txt_Correo.Location = new System.Drawing.Point(12, 350);
            this.txt_Correo.Name = "txt_Correo";
            this.txt_Correo.Size = new System.Drawing.Size(100, 20);
            this.txt_Correo.TabIndex = 32;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.Imprimir);
            // 
            // VentaPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(916, 455);
            this.Controls.Add(this.txt_Correo);
            this.Controls.Add(this.txt_Telefono);
            this.Controls.Add(this.txt_RFC);
            this.Controls.Add(this.txt_CodigPost);
            this.Controls.Add(this.txt_Direccion);
            this.Controls.Add(this.txt_UsoCFDI);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txt_Cantidad);
            this.Controls.Add(this.btn_Facturar);
            this.Controls.Add(this.txt_Cliente);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txt_NFactura);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btn_BuscarCliente);
            this.Controls.Add(this.txt_CodigoCliente);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lbl_Total);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_CodgProd);
            this.Controls.Add(this.txt_AgregarProd);
            this.Controls.Add(this.btn_Cerrar);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "VentaPrincipal";
            this.Text = "VentanaPrincipal";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Cerrar;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem Menu_Archivo;
        private System.Windows.Forms.ToolStripMenuItem Menu_ImpVenta;
        private System.Windows.Forms.ToolStripMenuItem Menu_Usuarios;
        private System.Windows.Forms.ToolStripMenuItem Menu_Inventario;
        private System.Windows.Forms.Button txt_AgregarProd;
        private System.Windows.Forms.TextBox txt_CodgProd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lbl_SubTotal;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_Total;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_CodigoCliente;
        private System.Windows.Forms.Button btn_BuscarCliente;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_NFactura;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_Cliente;
        private System.Windows.Forms.Button btn_Facturar;
        private System.Windows.Forms.TextBox txt_Cantidad;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_Impuestos;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ToolStripMenuItem Menu_Reportes;
        private System.Windows.Forms.ToolStripMenuItem Menu_HistFactura;
        private System.Windows.Forms.ToolStripMenuItem Menu_Clientes;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_MetodoPago;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_UsoCFDI;
        private System.Windows.Forms.ToolStripTextBox txt_ImpVIni;
        private System.Windows.Forms.TextBox txt_Direccion;
        private System.Windows.Forms.TextBox txt_CodigPost;
        private System.Windows.Forms.TextBox txt_RFC;
        private System.Windows.Forms.TextBox txt_Telefono;
        private System.Windows.Forms.TextBox txt_Correo;
        private System.Drawing.Printing.PrintDocument printDocument1;
    }
}