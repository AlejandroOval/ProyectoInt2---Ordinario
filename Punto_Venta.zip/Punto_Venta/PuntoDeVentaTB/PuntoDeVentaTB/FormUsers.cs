﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Negocios;

namespace PuntoDeVentaTB
{
    public partial class FormUsers : Form
    {

        conexionSQLN cn = new conexionSQLN();

        public FormUsers()
        {
            InitializeComponent();
            dataGridView1.DataSource = cn.ConSultaDT();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Btn_FUsers_NuevoUser_Click(object sender, EventArgs e)
        {
            
            cn.InsertarUsuario(txt_Nombre.Text,txt_Apellido.Text,txt_dni.Text,txt_Telefono.Text,txt_usuario.Text,txt_contrasena.Text);
            dataGridView1.DataSource = cn.ConSultaDT();
        }

        private void Btn_FUsers_ModfUser_Click(object sender, EventArgs e)
        {
            // nom,apel,dni,tel,user,pass
            cn.ModificarUsuario(txt_Nombre.Text, txt_Apellido.Text, txt_dni.Text, txt_Telefono.Text, txt_usuario.Text, txt_contrasena.Text);
            dataGridView1.DataSource = cn.ConSultaDT();
        }

        private void Btn_FUsers_ElimUser_Click(object sender, EventArgs e)
        {
            cn.EliminarUsuario(txt_dni.Text);
            dataGridView1.DataSource = cn.ConSultaDT();
        }

        private void Btn_FUsers_Cerrar_Click(object sender, EventArgs e)
        {
            VentaPrincipal v1 = new VentaPrincipal();
            this.Hide();
            v1.ShowDialog();
            this.Show();

        }

        private void txt_NEmp_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
