﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Negocios;

namespace PuntoDeVentaTB
{
    public partial class Clientes : Form
    {
        conexionSQLN cn = new conexionSQLN();
        
        public Clientes()
        {
            InitializeComponent();
            dataGridView1.DataSource = cn.ConSultaClientes();
        }

        private void btn_cerrar_Click(object sender, EventArgs e)
        {
            VentaPrincipal v1 = new VentaPrincipal();
            this.Hide();
            v1.ShowDialog();
            this.Show();
        }

        private void btn_NCliente_Click(object sender, EventArgs e)
        {
            // Rfc,NomCl,CodgP,DircCl,TelCl,CorreoCl
            cn.InsertarCliente(txt_rfcCl.Text,txt_NomCl.Text,txt_CodPCl.Text,txt_DicCl.Text,txt_TelCl.Text,txt_CorreoCl.Text);
            dataGridView1.DataSource = cn.ConSultaClientes();
        }

        private void btn_editar_Click(object sender, EventArgs e)
        {
            cn.ModificarCliente(txt_rfcCl.Text, txt_NomCl.Text, txt_CodPCl.Text, txt_DicCl.Text, txt_TelCl.Text, txt_CorreoCl.Text);
            dataGridView1.DataSource = cn.ConSultaClientes();
        }
    }
}
