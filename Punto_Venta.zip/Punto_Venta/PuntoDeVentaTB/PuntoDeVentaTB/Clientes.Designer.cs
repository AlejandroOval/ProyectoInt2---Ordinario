﻿namespace PuntoDeVentaTB
{
    partial class Clientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Clientes));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btn_cerrar = new System.Windows.Forms.Button();
            this.txt_rfcCl = new System.Windows.Forms.TextBox();
            this.txt_NomCl = new System.Windows.Forms.TextBox();
            this.txt_DicCl = new System.Windows.Forms.TextBox();
            this.txt_CorreoCl = new System.Windows.Forms.TextBox();
            this.txt_CodPCl = new System.Windows.Forms.TextBox();
            this.txt_TelCl = new System.Windows.Forms.TextBox();
            this.btn_NCliente = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_editar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(13, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(119, 118);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(138, 25);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(650, 238);
            this.dataGridView1.TabIndex = 1;
            // 
            // btn_cerrar
            // 
            this.btn_cerrar.Location = new System.Drawing.Point(678, 400);
            this.btn_cerrar.Name = "btn_cerrar";
            this.btn_cerrar.Size = new System.Drawing.Size(110, 38);
            this.btn_cerrar.TabIndex = 2;
            this.btn_cerrar.Text = "Cerrar";
            this.btn_cerrar.UseVisualStyleBackColor = true;
            this.btn_cerrar.Click += new System.EventHandler(this.btn_cerrar_Click);
            // 
            // txt_rfcCl
            // 
            this.txt_rfcCl.Location = new System.Drawing.Point(321, 298);
            this.txt_rfcCl.Name = "txt_rfcCl";
            this.txt_rfcCl.Size = new System.Drawing.Size(141, 20);
            this.txt_rfcCl.TabIndex = 3;
            // 
            // txt_NomCl
            // 
            this.txt_NomCl.Location = new System.Drawing.Point(146, 298);
            this.txt_NomCl.Name = "txt_NomCl";
            this.txt_NomCl.Size = new System.Drawing.Size(141, 20);
            this.txt_NomCl.TabIndex = 4;
            // 
            // txt_DicCl
            // 
            this.txt_DicCl.Location = new System.Drawing.Point(497, 298);
            this.txt_DicCl.Name = "txt_DicCl";
            this.txt_DicCl.Size = new System.Drawing.Size(141, 20);
            this.txt_DicCl.TabIndex = 5;
            // 
            // txt_CorreoCl
            // 
            this.txt_CorreoCl.Location = new System.Drawing.Point(497, 361);
            this.txt_CorreoCl.Name = "txt_CorreoCl";
            this.txt_CorreoCl.Size = new System.Drawing.Size(141, 20);
            this.txt_CorreoCl.TabIndex = 6;
            // 
            // txt_CodPCl
            // 
            this.txt_CodPCl.Location = new System.Drawing.Point(146, 361);
            this.txt_CodPCl.Name = "txt_CodPCl";
            this.txt_CodPCl.Size = new System.Drawing.Size(141, 20);
            this.txt_CodPCl.TabIndex = 7;
            // 
            // txt_TelCl
            // 
            this.txt_TelCl.Location = new System.Drawing.Point(321, 361);
            this.txt_TelCl.Name = "txt_TelCl";
            this.txt_TelCl.Size = new System.Drawing.Size(141, 20);
            this.txt_TelCl.TabIndex = 8;
            // 
            // btn_NCliente
            // 
            this.btn_NCliente.Location = new System.Drawing.Point(146, 400);
            this.btn_NCliente.Name = "btn_NCliente";
            this.btn_NCliente.Size = new System.Drawing.Size(141, 31);
            this.btn_NCliente.TabIndex = 9;
            this.btn_NCliente.Text = "Registrar";
            this.btn_NCliente.UseVisualStyleBackColor = true;
            this.btn_NCliente.Click += new System.EventHandler(this.btn_NCliente_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(146, 279);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Nombre:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(143, 342);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Codigo Postal:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(321, 279);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "RFC:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(321, 342);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Telefono:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(497, 279);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Direccion:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(497, 342);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Correo:";
            // 
            // btn_editar
            // 
            this.btn_editar.Location = new System.Drawing.Point(321, 400);
            this.btn_editar.Name = "btn_editar";
            this.btn_editar.Size = new System.Drawing.Size(141, 31);
            this.btn_editar.TabIndex = 16;
            this.btn_editar.Text = "Editar";
            this.btn_editar.UseVisualStyleBackColor = true;
            this.btn_editar.Click += new System.EventHandler(this.btn_editar_Click);
            // 
            // Clientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_editar);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_NCliente);
            this.Controls.Add(this.txt_TelCl);
            this.Controls.Add(this.txt_CodPCl);
            this.Controls.Add(this.txt_CorreoCl);
            this.Controls.Add(this.txt_DicCl);
            this.Controls.Add(this.txt_NomCl);
            this.Controls.Add(this.txt_rfcCl);
            this.Controls.Add(this.btn_cerrar);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Clientes";
            this.Text = "Clientes";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btn_cerrar;
        private System.Windows.Forms.TextBox txt_rfcCl;
        private System.Windows.Forms.TextBox txt_NomCl;
        private System.Windows.Forms.TextBox txt_DicCl;
        private System.Windows.Forms.TextBox txt_CorreoCl;
        private System.Windows.Forms.TextBox txt_CodPCl;
        private System.Windows.Forms.TextBox txt_TelCl;
        private System.Windows.Forms.Button btn_NCliente;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn_editar;
    }
}