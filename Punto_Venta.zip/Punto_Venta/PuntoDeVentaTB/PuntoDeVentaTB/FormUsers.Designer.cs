﻿namespace PuntoDeVentaTB
{
    partial class FormUsers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_FUsers_Cerrar = new System.Windows.Forms.Button();
            this.Btn_FUsers_NuevoUser = new System.Windows.Forms.Button();
            this.Btn_FUsers_ModfUser = new System.Windows.Forms.Button();
            this.Btn_FUsers_ElimUser = new System.Windows.Forms.Button();
            this.txt_Nombre = new System.Windows.Forms.TextBox();
            this.txt_Apellido = new System.Windows.Forms.TextBox();
            this.txt_dni = new System.Windows.Forms.TextBox();
            this.txt_Telefono = new System.Windows.Forms.TextBox();
            this.txt_usuario = new System.Windows.Forms.TextBox();
            this.txt_contrasena = new System.Windows.Forms.TextBox();
            this.Users_Name = new System.Windows.Forms.Label();
            this.Users_LastName = new System.Windows.Forms.Label();
            this.Users_NumEm = new System.Windows.Forms.Label();
            this.Users_Phone = new System.Windows.Forms.Label();
            this.Users_User = new System.Windows.Forms.Label();
            this.Users_Password = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Btn_FUsers_Cerrar
            // 
            this.Btn_FUsers_Cerrar.Location = new System.Drawing.Point(830, 403);
            this.Btn_FUsers_Cerrar.Name = "Btn_FUsers_Cerrar";
            this.Btn_FUsers_Cerrar.Size = new System.Drawing.Size(148, 44);
            this.Btn_FUsers_Cerrar.TabIndex = 0;
            this.Btn_FUsers_Cerrar.Text = "Cerrar";
            this.Btn_FUsers_Cerrar.UseVisualStyleBackColor = true;
            this.Btn_FUsers_Cerrar.Click += new System.EventHandler(this.Btn_FUsers_Cerrar_Click);
            // 
            // Btn_FUsers_NuevoUser
            // 
            this.Btn_FUsers_NuevoUser.Location = new System.Drawing.Point(13, 403);
            this.Btn_FUsers_NuevoUser.Name = "Btn_FUsers_NuevoUser";
            this.Btn_FUsers_NuevoUser.Size = new System.Drawing.Size(148, 44);
            this.Btn_FUsers_NuevoUser.TabIndex = 1;
            this.Btn_FUsers_NuevoUser.Text = "Nuevo Usuario";
            this.Btn_FUsers_NuevoUser.UseVisualStyleBackColor = true;
            this.Btn_FUsers_NuevoUser.Click += new System.EventHandler(this.Btn_FUsers_NuevoUser_Click);
            // 
            // Btn_FUsers_ModfUser
            // 
            this.Btn_FUsers_ModfUser.Location = new System.Drawing.Point(181, 403);
            this.Btn_FUsers_ModfUser.Name = "Btn_FUsers_ModfUser";
            this.Btn_FUsers_ModfUser.Size = new System.Drawing.Size(148, 44);
            this.Btn_FUsers_ModfUser.TabIndex = 2;
            this.Btn_FUsers_ModfUser.Text = "Modificar Usuario";
            this.Btn_FUsers_ModfUser.UseVisualStyleBackColor = true;
            this.Btn_FUsers_ModfUser.Click += new System.EventHandler(this.Btn_FUsers_ModfUser_Click);
            // 
            // Btn_FUsers_ElimUser
            // 
            this.Btn_FUsers_ElimUser.Location = new System.Drawing.Point(348, 403);
            this.Btn_FUsers_ElimUser.Name = "Btn_FUsers_ElimUser";
            this.Btn_FUsers_ElimUser.Size = new System.Drawing.Size(148, 44);
            this.Btn_FUsers_ElimUser.TabIndex = 3;
            this.Btn_FUsers_ElimUser.Text = "Eliminar Usuario";
            this.Btn_FUsers_ElimUser.UseVisualStyleBackColor = true;
            this.Btn_FUsers_ElimUser.Click += new System.EventHandler(this.Btn_FUsers_ElimUser_Click);
            // 
            // txt_Nombre
            // 
            this.txt_Nombre.Location = new System.Drawing.Point(13, 351);
            this.txt_Nombre.Name = "txt_Nombre";
            this.txt_Nombre.Size = new System.Drawing.Size(132, 20);
            this.txt_Nombre.TabIndex = 4;
            // 
            // txt_Apellido
            // 
            this.txt_Apellido.Location = new System.Drawing.Point(162, 351);
            this.txt_Apellido.Name = "txt_Apellido";
            this.txt_Apellido.Size = new System.Drawing.Size(132, 20);
            this.txt_Apellido.TabIndex = 5;
            // 
            // txt_dni
            // 
            this.txt_dni.Location = new System.Drawing.Point(310, 351);
            this.txt_dni.Name = "txt_dni";
            this.txt_dni.Size = new System.Drawing.Size(132, 20);
            this.txt_dni.TabIndex = 6;
            this.txt_dni.TextChanged += new System.EventHandler(this.txt_NEmp_TextChanged);
            // 
            // txt_Telefono
            // 
            this.txt_Telefono.Location = new System.Drawing.Point(464, 351);
            this.txt_Telefono.Name = "txt_Telefono";
            this.txt_Telefono.Size = new System.Drawing.Size(132, 20);
            this.txt_Telefono.TabIndex = 7;
            // 
            // txt_usuario
            // 
            this.txt_usuario.Location = new System.Drawing.Point(6, 47);
            this.txt_usuario.Name = "txt_usuario";
            this.txt_usuario.Size = new System.Drawing.Size(132, 20);
            this.txt_usuario.TabIndex = 8;
            // 
            // txt_contrasena
            // 
            this.txt_contrasena.Location = new System.Drawing.Point(163, 47);
            this.txt_contrasena.Name = "txt_contrasena";
            this.txt_contrasena.Size = new System.Drawing.Size(132, 20);
            this.txt_contrasena.TabIndex = 9;
            // 
            // Users_Name
            // 
            this.Users_Name.AutoSize = true;
            this.Users_Name.Location = new System.Drawing.Point(12, 335);
            this.Users_Name.Name = "Users_Name";
            this.Users_Name.Size = new System.Drawing.Size(44, 13);
            this.Users_Name.TabIndex = 10;
            this.Users_Name.Text = "Nombre";
            this.Users_Name.Click += new System.EventHandler(this.label1_Click);
            // 
            // Users_LastName
            // 
            this.Users_LastName.AutoSize = true;
            this.Users_LastName.Location = new System.Drawing.Point(159, 335);
            this.Users_LastName.Name = "Users_LastName";
            this.Users_LastName.Size = new System.Drawing.Size(49, 13);
            this.Users_LastName.TabIndex = 11;
            this.Users_LastName.Text = "Apellidos";
            // 
            // Users_NumEm
            // 
            this.Users_NumEm.AutoSize = true;
            this.Users_NumEm.Location = new System.Drawing.Point(307, 335);
            this.Users_NumEm.Name = "Users_NumEm";
            this.Users_NumEm.Size = new System.Drawing.Size(69, 13);
            this.Users_NumEm.TabIndex = 12;
            this.Users_NumEm.Text = "Nº Empleado";
            // 
            // Users_Phone
            // 
            this.Users_Phone.AutoSize = true;
            this.Users_Phone.Location = new System.Drawing.Point(461, 335);
            this.Users_Phone.Name = "Users_Phone";
            this.Users_Phone.Size = new System.Drawing.Size(49, 13);
            this.Users_Phone.TabIndex = 13;
            this.Users_Phone.Text = "Telefono";
            // 
            // Users_User
            // 
            this.Users_User.AutoSize = true;
            this.Users_User.Location = new System.Drawing.Point(6, 31);
            this.Users_User.Name = "Users_User";
            this.Users_User.Size = new System.Drawing.Size(43, 13);
            this.Users_User.TabIndex = 14;
            this.Users_User.Text = "Usuario";
            // 
            // Users_Password
            // 
            this.Users_Password.AutoSize = true;
            this.Users_Password.Location = new System.Drawing.Point(165, 31);
            this.Users_Password.Name = "Users_Password";
            this.Users_Password.Size = new System.Drawing.Size(61, 13);
            this.Users_Password.TabIndex = 15;
            this.Users_Password.Text = "Contraseña";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(13, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(965, 286);
            this.dataGridView1.TabIndex = 16;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txt_usuario);
            this.groupBox1.Controls.Add(this.Users_User);
            this.groupBox1.Controls.Add(this.Users_Password);
            this.groupBox1.Controls.Add(this.txt_contrasena);
            this.groupBox1.Location = new System.Drawing.Point(640, 304);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(338, 84);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Informacion de acceso";
            // 
            // FormUsers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(990, 459);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Users_Phone);
            this.Controls.Add(this.Users_NumEm);
            this.Controls.Add(this.Users_LastName);
            this.Controls.Add(this.Users_Name);
            this.Controls.Add(this.txt_Telefono);
            this.Controls.Add(this.txt_dni);
            this.Controls.Add(this.txt_Apellido);
            this.Controls.Add(this.txt_Nombre);
            this.Controls.Add(this.Btn_FUsers_ElimUser);
            this.Controls.Add(this.Btn_FUsers_ModfUser);
            this.Controls.Add(this.Btn_FUsers_NuevoUser);
            this.Controls.Add(this.Btn_FUsers_Cerrar);
            this.Name = "FormUsers";
            this.Text = "FormUsers";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn_FUsers_Cerrar;
        private System.Windows.Forms.Button Btn_FUsers_NuevoUser;
        private System.Windows.Forms.Button Btn_FUsers_ModfUser;
        private System.Windows.Forms.Button Btn_FUsers_ElimUser;
        private System.Windows.Forms.TextBox txt_Nombre;
        private System.Windows.Forms.TextBox txt_Apellido;
        private System.Windows.Forms.TextBox txt_dni;
        private System.Windows.Forms.TextBox txt_Telefono;
        private System.Windows.Forms.TextBox txt_usuario;
        private System.Windows.Forms.TextBox txt_contrasena;
        private System.Windows.Forms.Label Users_Name;
        private System.Windows.Forms.Label Users_LastName;
        private System.Windows.Forms.Label Users_NumEm;
        private System.Windows.Forms.Label Users_Phone;
        private System.Windows.Forms.Label Users_User;
        private System.Windows.Forms.Label Users_Password;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}