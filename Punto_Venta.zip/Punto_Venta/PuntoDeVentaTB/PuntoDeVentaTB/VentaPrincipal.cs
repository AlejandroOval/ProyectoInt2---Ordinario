﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Negocios;
using Entidades;
using System.Drawing.Printing;

namespace PuntoDeVentaTB
{
    public partial class VentaPrincipal : Form
    {
        private DataTable dt;
        conexionSQLN cn = new conexionSQLN();
        private double subtotal = 0;
        private double Total = 0;

        public VentaPrincipal()
        {
            InitializeComponent();
            txt_Impuestos.Text = txt_ImpVIni.Text;

            dt = new DataTable();
            dt.Columns.Add("Codigo");
            dt.Columns.Add("Producto");
            dt.Columns.Add("Precio x Unidad");
            dt.Columns.Add("Cantidad");
            dt.Columns.Add("Precio Total");

            dataGridView1.DataSource = dt;

            txt_NFactura.Text = cn.ConsultaFactura();
        }

        private void btn_Cerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void Menu_Usuarios_Click(object sender, EventArgs e)
        {
            FormUsers v1 = new FormUsers();
            this.Hide();
            v1.ShowDialog();
            this.Show();
        }

        private void Menu_Inventario_Click(object sender, EventArgs e)
        {
            Inventario v1 = new Inventario();
            this.Hide();
            v1.ShowDialog();
            this.Show();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void ImpVentaChanged(object sender, EventArgs e)
        {
            txt_Impuestos.Text = txt_ImpVIni.Text ;
        }

        private void txt_AgregarProd_Click(object sender, EventArgs e)
        {
            var resultado = cn.ConsultaProdInv(txt_CodgProd.Text);
            DataRow row = dt.NewRow();

            row["Codigo"] = txt_CodgProd.Text;
            row["Producto"] = resultado.Item1;
            row["Precio x Unidad"] = resultado.Item2;
            row["Cantidad"] = txt_Cantidad.Text;
            row["Precio Total"] = Int32.Parse(txt_Cantidad.Text) * double.Parse(resultado.Item2);


            dt.Rows.Add(row);

            subtotal = subtotal + (Int32.Parse(txt_Cantidad.Text) * double.Parse(resultado.Item2));
            Total = subtotal + (subtotal * double.Parse(txt_ImpVIni.Text));


            lbl_SubTotal.Text = subtotal.ToString();
            lbl_Total.Text = Total.ToString();
        }

       private void txt_Impuestos_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_BuscarCliente_Click(object sender, EventArgs e)
        {
            var resultado2  =cn.ConsultaCliente(txt_CodigoCliente.Text);

            txt_RFC.Text = resultado2.Item1;
            txt_Cliente.Text = resultado2.Item2;
            txt_CodigPost.Text = resultado2.Item3;
            txt_Direccion.Text = resultado2.Item4;
            txt_Telefono.Text = resultado2.Item5;
            txt_Correo.Text = resultado2.Item6;

        }

        private void btn_Facturar_Click(object sender, EventArgs e)
        {
            
            List<Factura> listFact = new List<Factura>();
            

            foreach (DataRow row in dt.Rows)
            {
                Factura fact = new Factura();

                fact.Codigo = row["Codigo"].ToString();
                fact.Producto = row["Producto"].ToString();
                fact.PrecioxUnidad = row["Precio x Unidad"].ToString();
                fact.Cantidad = row["Cantidad"].ToString();
                fact.PrecioTotal = row["Precio Total"].ToString();
                fact.Cliente = txt_Cliente.Text;
                fact.Direccion = txt_Direccion.Text;
                fact.CodigoPost = txt_CodigPost.Text;
                fact.RFC = txt_RFC.Text;
                fact.CDFI = txt_UsoCFDI.Text;
                fact.TelfonoCl = txt_Telefono.Text;
                fact.Correo = txt_Correo.Text;
                fact.MetodoPago = txt_MetodoPago.Text;
                fact.NumFactura = txt_NFactura.Text;
                fact.SubTotal = subtotal.ToString();
                fact.Total = Total.ToString();


                listFact.Add(fact);
            }

            cn.InsertarFactura(listFact);

            txt_NFactura.Text = cn.ConsultaFactura();
            MessageBox.Show(listFact.Count().ToString());

            printDocument1 = new PrintDocument();
            PrinterSettings ps = new PrinterSettings();
            printDocument1.PrinterSettings = ps;
            printDocument1.PrintPage += Imprimir;
            printDocument1.Print();




        }



        private void Imprimir(object sender, PrintPageEventArgs e)
        {
            Font font = new Font("Arial", 15);
            int ancho = 900;
            int y = 20;

            e.Graphics.DrawString("[Proyecto Integrador 2]", font, Brushes.Black, new RectangleF(10, y + 20, ancho, 20));
            e.Graphics.DrawString("Factura # " + txt_NFactura.Text, font, Brushes.Black, new RectangleF(550, y + 20, ancho, 20));
            e.Graphics.DrawString("Factura A:", font, Brushes.Black, new RectangleF(10, y + 60, ancho, 20));
            e.Graphics.DrawString("Nombre: " + txt_Cliente.Text, font, Brushes.Black, new RectangleF(10, y + 85, ancho, 20));
            e.Graphics.DrawString("Domicilio Fiscal: " + txt_Direccion.Text, font, Brushes.Black, new RectangleF(10, y + 115, ancho, 20));
            e.Graphics.DrawString("Codigo Postal: " + txt_CodigPost.Text, font, Brushes.Black, new RectangleF(10, y + 145, ancho, 20));
            e.Graphics.DrawString("Telefono: " + txt_Telefono.Text, font, Brushes.Black, new RectangleF(10, y + 175, ancho, 20));
            e.Graphics.DrawString("Correo: " + txt_Correo.Text, font, Brushes.Black, new RectangleF(10, y + 205, ancho, 20));
            e.Graphics.DrawString("Fecha: 28/11/23", font, Brushes.Black, new RectangleF(550, y + 60, ancho, 20));
            e.Graphics.DrawString("ID Cliente: " + txt_CodigoCliente.Text, font, Brushes.Black, new RectangleF(550, y + 85, ancho, 20));
            e.Graphics.DrawString("Terminos: " + txt_UsoCFDI.Text, font, Brushes.Black, new RectangleF(550, y + 115, ancho, 20));


            e.Graphics.DrawString("---Productos---", font, Brushes.Black, new RectangleF(360, y + 250, ancho, 20));

            foreach (DataRow row in dt.Rows)
            {
                e.Graphics.DrawString(row["Codigo"].ToString() + " | " +
                    row["Producto"].ToString() + " | " +
                    row["Cantidad"].ToString() + " | " +
                    row["Precio x Unidad"].ToString() + " | " + //|
                    row["Precio Total"].ToString()
                    ,font, Brushes.Black, new RectangleF(320, y + 280, ancho, 20));
            }

            e.Graphics.DrawString("SubTotal: " + subtotal.ToString() , font, Brushes.Black, new RectangleF(550, y + 320, ancho, 20));
            e.Graphics.DrawString("Total $ " + Total.ToString(), font, Brushes.Black, new RectangleF(550, y + 340, ancho, 20));



        }

        private void Menu_Clientes_Click(object sender, EventArgs e)
        {
            Clientes v1 = new Clientes();
            this.Hide();
            v1.ShowDialog();
            this.Show();
        }
    }
}
