﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Entidades
{
    public class Factura
    {

        private string codigo = "";
        private string producto = "";
        private string precioxUnidad = "";
        private string cantidad = "";
        private string precioTotal = "";
        private string cliente = "";
        private string direccion = "";
        private string codigoPost = "";
        private string rFC = "";
        private string cDFI = "";
        private string telfonoCl = "";
        private string correo = "";
        private string metodoPago = "";
        private string numFactura = "";
        private string subTotal = "";
        private string total = "";

        public string Codigo { get => codigo; set => codigo = value; }
        public string Producto { get => producto; set => producto = value; }
        public string PrecioxUnidad { get => precioxUnidad; set => precioxUnidad = value; }
        public string Cantidad { get => cantidad; set => cantidad = value; }
        public string PrecioTotal { get => precioTotal; set => precioTotal = value; }
        public string Cliente { get => cliente; set => cliente = value; }
        public string Direccion { get => direccion; set => direccion = value; }
        public string CodigoPost { get => codigoPost; set => codigoPost = value; }
        public string RFC { get => rFC; set => rFC = value; }
        public string TelfonoCl { get => telfonoCl; set => telfonoCl = value; }
        public string Correo { get => correo; set => correo = value; }
        public string MetodoPago { get => metodoPago; set => metodoPago = value; }
        public string NumFactura { get => numFactura; set => numFactura = value; }
        public string SubTotal { get => subTotal; set => subTotal = value; }
        public string Total { get => total; set => total = value; }
        public string CDFI { get => cDFI; set => cDFI = value; }
    }
}
