﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Negocios;

namespace PuntoDeVentaTB
{
    public partial class Inventario : Form
    {
        conexionSQLN cn = new conexionSQLN();
        public Inventario()
        {
            InitializeComponent();
            dataGridView1.DataSource = cn.ConsultaProductosDT();
        }


        private void Btn_CerrarInv_Click(object sender, EventArgs e)
        {
            VentaPrincipal v1 = new VentaPrincipal();
            this.Hide();
            v1.ShowDialog();
            this.Show();
        }

        private void Btn_NuevProd_Click(object sender, EventArgs e)
        {
            // Prod,Catg,Prec,Cant,Codg
           cn.InsertarProducto(txt_Producto.Text, txt_Categoria.Text, txt_Precio.Text, txt_Cantidad.Text,txt_IDProd.Text);
           dataGridView1.DataSource =  cn.ConsultaProductosDT();
        }

        private void btn_ModProd_Click(object sender, EventArgs e)
        {
            cn.ModificarProducto(txt_Producto.Text, txt_Categoria.Text, txt_Precio.Text, txt_Cantidad.Text,txt_IDProd.Text);
            dataGridView1.DataSource = cn.ConsultaProductosDT();
        }
    }
}
