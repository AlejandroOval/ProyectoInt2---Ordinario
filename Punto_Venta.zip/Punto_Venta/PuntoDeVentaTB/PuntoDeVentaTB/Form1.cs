﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Negocios;

namespace PuntoDeVentaTB
{
    public partial class Form1 : Form
    {

        conexionSQLN cn = new conexionSQLN();


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (cn.conSql(txt_usuario.Text, txt_contrasena.Text) ==1 )
            {
                MessageBox.Show("El usuario ha sido encontrado");

                this.Hide();
                VentaPrincipal v1 = new VentaPrincipal();
                v1.Show();

            }
            else 
            { 
               MessageBox.Show("El usuario no ha sido encontrado"); 
            }
        }

        private void btn_Salir_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }
    }
}
